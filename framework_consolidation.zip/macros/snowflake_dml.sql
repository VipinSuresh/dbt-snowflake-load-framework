
{% macro execute_snowflake_merge(
    merge_sql,
    statement_name='enterprise_merge',
    insert_only=false,
    update_only=false
) %}

    {% if insert_only and update_only %}
    {{ exceptions.raise_compiler_error(
        'DML: insert_only and update_only cannot both be true.'
    ) }}
    {% endif %}

    {% if not execute %}
        {% do return({}) %}
    {% endif %}

    {% if adapter.type() != 'snowflake' %}
        {{ exceptions.raise_compiler_error(
            'DML: Snowflake adapter is required.'
        ) }}
    {% endif %}

    {% if flags.WHICH not in ['run', 'build', 'run-operation'] %}
        {{ exceptions.raise_compiler_error(
            'DML: Execution is only allowed during run/build '
            ~ 'or an explicit run-operation test.'
        ) }}
    {% endif %}

    {% call statement(
        statement_name,
        fetch_result=True,
        auto_begin=False
    ) %}
        {{ merge_sql }}
    {% endcall %}

    {% set result = load_result(statement_name) %}
    {% set response = result['response'] %}
    {% set result_table = result['table'] %}

    {% set counts = {
        'rows_inserted': none,
        'rows_updated': none,
        'rows_deleted': 0
    } %}

    {# Prefer adapter-provided DML statistics #}

    {% if response.rows_inserted is defined
          and response.rows_inserted is not none %}
        {% do counts.update({
            'rows_inserted': response.rows_inserted | int
        }) %}
    {% endif %}

    {% if response.rows_updated is defined
          and response.rows_updated is not none %}
        {% do counts.update({
            'rows_updated': response.rows_updated | int
        }) %}
    {% endif %}

    {% if response.rows_deleted is defined
          and response.rows_deleted is not none %}
        {% do counts.update({
            'rows_deleted': response.rows_deleted | int
        }) %}
    {% endif %}

    {# Fallback: Snowflake MERGE result columns #}

    {% if result_table is not none
          and result_table.rows | length > 0 %}

        {% set row = result_table.rows[0] %}

        {% for col_name in result_table.column_names %}

            {% set label = col_name | lower | trim %}
            {% set value = row[loop.index0] | int %}

            {% if label == 'number of rows inserted' %}
                {% do counts.update({
                    'rows_inserted': value
                }) %}
            {% elif label == 'number of rows updated' %}
                {% do counts.update({
                    'rows_updated': value
                }) %}
            {% elif label == 'number of rows deleted' %}
                {% do counts.update({
                    'rows_deleted': value
                }) %}
            {% endif %}

        {% endfor %}

    {% endif %}

    {# INSERT-only MERGE has no UPDATE clause.
       Snowflake may omit updated-row statistics entirely.
       Only infer zero when inserted count is available
       and total affected rows confirms that count.
    #}

    {% if insert_only
        and counts['rows_inserted'] is not none
        and counts['rows_updated'] is none
        and response.rows_affected is defined
        and response.rows_affected is not none
        and (response.rows_affected | int)
            == (counts['rows_inserted'] | int) %}

        {% do counts.update({'rows_updated': 0}) %}

    {% endif %}

    {# UPDATE-only MERGE contains no INSERT or DELETE clause.
       Snowflake may omit inserted-row statistics entirely.
       Infer zero only when the updated count agrees with
       the adapters total affected-row count.
    #}

    {% if update_only
        and counts['rows_inserted'] is none
        and counts['rows_updated'] is not none
        and counts['rows_deleted'] == 0
        and response.rows_affected is defined
        and response.rows_affected is not none
        and (response.rows_affected | int)
            == (counts['rows_updated'] | int) %}

        {% do counts.update({'rows_inserted': 0}) %}

    {% endif %}

    {% if counts['rows_inserted'] is none
          or counts['rows_updated'] is none %}

        {{ exceptions.raise_compiler_error(
            'DML: MERGE executed, but individual row counts '
            ~ 'were not available. Verify adapter response.'
        ) }}

    {% endif %}

    {% set query_id = none %}

    {% if response.query_id is defined %}
        {% set query_id = response.query_id %}
    {% endif %}

    {% do counts.update({'query_id': query_id}) %}

    {% do log(
        'MERGE COMPLETE | Inserted=' ~ counts['rows_inserted']
        ~ ' | Updated=' ~ counts['rows_updated']
        ~ ' | Deleted=' ~ counts['rows_deleted'],
        info=True
    ) %}

    {% do return(counts) %}

{% endmacro %}


{% macro demo_test_snowflake_merge() %}

    {% set sql %}

        MERGE INTO
            DBT_DEMO.DBT_WORK.DML_TEST_TARGET tgt

        USING (
            SELECT
                COLUMN1::NUMBER AS ID,
                COLUMN2::VARCHAR AS VAL
            FROM VALUES
                (1, 'updated'),
                (2, 'new')
        ) src

        ON tgt.ID = src.ID

        WHEN MATCHED
            AND tgt.VAL IS DISTINCT FROM src.VAL
        THEN UPDATE SET
            VAL = src.VAL

        WHEN NOT MATCHED
        THEN INSERT (ID, VAL)
        VALUES (src.ID, src.VAL)

    {% endset %}

    {% set stats = execute_snowflake_merge(sql) %}

    {% if stats['rows_inserted'] != 1
          or stats['rows_updated'] != 1 %}

        {{ exceptions.raise_compiler_error(
            'DEMO: Expected one insert and one update. '
            ~ 'Reset DML_TEST_TARGET before rerunning.'
        ) }}

    {% endif %}

    {% do log(
        'DML TEST PASSED | Query ID=' ~ stats['query_id'],
        info=True
    ) %}

{% endmacro %}
