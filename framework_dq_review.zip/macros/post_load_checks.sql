
{% macro run_type1_post_load_checks(
    source_relation,
    target_relation,
    natural_keys,
    model_execution_id,
    etl_nr,
    target_before,
    target_after,
    dml_stats
) %}

    {% set failures = [] %}

    {% set keys = [] %}
    {% set join_conditions = [] %}
    {% set null_conditions = [] %}

    {% for key in natural_keys %}
        {% set q = adapter.quote(key | upper) %}
        {% do keys.append(q) %}
        {% do join_conditions.append(
            'src.' ~ q ~ ' = tgt.' ~ q
        ) %}
        {% do null_conditions.append(
            'tgt.' ~ q ~ ' IS NULL'
        ) %}
    {% endfor %}

    {# 1. Reconcile target count with DML counts #}

    {% set expected_count =
        target_before
        + dml_stats['rows_inserted']
        - dml_stats['rows_deleted']
    %}

    {% set status = record_post_load_check(
        model_execution_id, etl_nr,
        'TYPE1_ROW_COUNT_DELTA',
        target_after, expected_count
    ) %}

    {% if status == 'FAIL' %}
        {% do failures.append('ROW_COUNT_DELTA') %}
    {% endif %}

    {# 2. Check target NULL natural keys #}

    {% set null_sql %}
        SELECT COUNT(*)
        FROM {{ target_relation }} tgt
        WHERE {{ null_conditions | join(' OR ') }}
    {% endset %}

    {% set null_result = run_query(null_sql) %}
    {% set null_rows = null_result.rows[0][0] | int %}

    {% set status = record_post_load_check(
        model_execution_id, etl_nr,
        'TYPE1_TARGET_NULL_KEYS',
        null_rows, 0
    ) %}

    {% if status == 'FAIL' %}
        {% do failures.append('TARGET_NULL_KEYS') %}
    {% endif %}

    {# 3. Check duplicate target natural keys #}

    {% set dup_sql %}
        SELECT COUNT(*)
        FROM (
            SELECT {{ keys | join(', ') }}
            FROM {{ target_relation }}
            GROUP BY {{ keys | join(', ') }}
            HAVING COUNT(*) > 1
        ) duplicate_groups
    {% endset %}

    {% set dup_result = run_query(dup_sql) %}
    {% set duplicate_groups = dup_result.rows[0][0] | int %}

    {% set status = record_post_load_check(
        model_execution_id, etl_nr,
        'TYPE1_TARGET_DUPLICATES',
        duplicate_groups, 0
    ) %}

    {% if status == 'FAIL' %}
        {% do failures.append('TARGET_DUPLICATES') %}
    {% endif %}

    {# 4. Compare source business data with target #}

    {% set source_columns =
        adapter.get_columns_in_relation(source_relation)
    %}

    {% set normalized_keys = [] %}

    {% for key in natural_keys %}
        {% do normalized_keys.append(key | upper) %}
    {% endfor %}

    {% set differences = [] %}

    {% for col in source_columns %}
        {% if col.name | upper not in normalized_keys %}
            {% set q = adapter.quote(col.name) %}
            {% do differences.append(
                'src.' ~ q
                ~ ' IS DISTINCT FROM tgt.' ~ q
            ) %}
        {% endif %}
    {% endfor %}

    {% set first_key = keys[0] %}

    {% set comparison_sql %}
        SELECT COUNT(*)
        FROM {{ source_relation }} src
        LEFT JOIN {{ target_relation }} tgt
            ON {{ join_conditions | join(' AND ') }}
        WHERE tgt.{{ first_key }} IS NULL
        {% if differences | length > 0 %}
            OR {{ differences | join(' OR ') }}
        {% endif %}
    {% endset %}

    {% set comparison_result = run_query(comparison_sql) %}
    {% set mismatch_rows =
        comparison_result.rows[0][0] | int
    %}

    {% set status = record_post_load_check(
        model_execution_id, etl_nr,
        'TYPE1_SOURCE_TARGET_MATCH',
        mismatch_rows, 0
    ) %}

    {% if status == 'FAIL' %}
        {% do failures.append('SOURCE_TARGET_MATCH') %}
    {% endif %}

    {# 5. Finalize the model DQ status #}

    {% set passed = failures | length == 0 %}

    {% do finalize_model_dq(
        model_execution_id,
        passed
    ) %}

    {% do return({
        'passed': passed,
        'failed_checks': failures
    }) %}

{% endmacro %}
