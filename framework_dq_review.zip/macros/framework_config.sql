
{% macro validate_enterprise_config(load_cfg) %}

    {# 1. Validate configuration object #}

    {% if load_cfg is not mapping %}
        {{ exceptions.raise_compiler_error(
            'ENTERPRISE_LOAD: Configuration must be a dictionary.'
        ) }}
    {% endif %}

    {# 2. Validate load type #}

    {% set load_type =
        load_cfg.get('load_type', '') | upper | trim %}

    {% set allowed_load_types = [
        'TYPE1',
        'TYPE2',
        'INSERT',
        'TRUNCATE_LOAD',
        'UPDATE'
    ] %}

    {% if load_type not in allowed_load_types %}
        {{ exceptions.raise_compiler_error(
            'ENTERPRISE_LOAD: Invalid load_type: ' ~ load_type
        ) }}
    {% endif %}

    {# 3. Validate natural keys #}

    {% set natural_keys = load_cfg.get('natural_keys', []) %}

    {% if natural_keys is not sequence
          or natural_keys is string %}
        {{ exceptions.raise_compiler_error(
            'ENTERPRISE_LOAD: natural_keys must be a list.'
        ) }}
    {% endif %}

    {% if load_type in ['TYPE1', 'TYPE2', 'UPDATE']
          and natural_keys | length == 0 %}
        {{ exceptions.raise_compiler_error(
            'ENTERPRISE_LOAD: Natural keys are required for '
            ~ load_type
        ) }}
    {% endif %}

    {# 4. Validate pre-load options #}

    {% set pre_load = load_cfg.get('pre_load', {}) %}

    {% if pre_load is not mapping %}
        {{ exceptions.raise_compiler_error(
            'ENTERPRISE_LOAD: pre_load must be a dictionary.'
        ) }}
    {% endif %}

    {% set column_match =
        pre_load.get('column_match', true) %}

    {% if column_match is not sameas true %}
        {{ exceptions.raise_compiler_error(
            'ENTERPRISE_LOAD: Column matching is mandatory.'
        ) }}
    {% endif %}

    {# 5. Validate post-load options #}

    {% set post_load = load_cfg.get('post_load', {}) %}

    {% if post_load is not mapping %}
        {{ exceptions.raise_compiler_error(
            'ENTERPRISE_LOAD: post_load must be a dictionary.'
        ) }}
    {% endif %}

    {# 6. Return normalized configuration #}

    {% set normalized = {
        'load_type': load_type,
        'natural_keys': natural_keys,
        'pre_load': {
            'column_match': true,
            'require_nonempty':
                pre_load.get('require_nonempty', true),
            'validate_keys':
                pre_load.get('validate_keys', true)
        },
        'post_load': {
            'reconcile_counts':
                post_load.get('reconcile_counts', true),
            'duplicate_check':
                post_load.get('duplicate_check', true)
        }
    } %}

    {% do log(
        'ENTERPRISE CONFIG VALIDATED: ' ~ load_type,
        info=true
    ) %}

    {% do return(normalized) %}

{% endmacro %}
